import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics.pairwise import cosine_similarity

df = pd.read_csv("Dataset .csv")
df_model = df.drop(columns=[
    'Restaurant ID', 'Restaurant Name', 'Address', 'Locality',
    'Locality Verbose', 'Rating color', 'Rating text'
])

df_model['Cuisines'].fillna(df_model['Cuisines'].mode()[0], inplace=True)

label_encoders = {}
for col in df_model.select_dtypes(include='object'):
    le = LabelEncoder()
    df_model[col] = le.fit_transform(df_model[col])
    label_encoders[col] = le

features = ['Cuisines', 'Price range', 'Average Cost for two']
X = df_model[features]
similarity = cosine_similarity(X)

def recommend_restaurants(user_preferences, top_n=5):
    user_df = pd.DataFrame([user_preferences])
    for col in user_df.columns:
        if col in label_encoders:
            if user_df[col].values[0] in label_encoders[col].classes_:
                user_df[col] = label_encoders[col].transform(user_df[col])
            else:
                return pd.DataFrame()
    user_X = user_df[features]
    user_similarity = cosine_similarity(user_X, X)
    top_indices = user_similarity.argsort()[0][-top_n:][::-1]
    return df.iloc[top_indices][['Restaurant Name', 'Cuisines', 'Average Cost for two', 'Aggregate rating']]

cuisine_list = []
for cuisines in df['Cuisines'].dropna():
    split_cuisines = [c.strip() for c in cuisines.split(',')]
    cuisine_list.extend(split_cuisines)

cuisine_counts = pd.Series(cuisine_list).value_counts()
top_cuisines = cuisine_counts.head(30).index.tolist()

print("Available Cuisines:\n")
for idx, cuisine in enumerate(top_cuisines):
    print(f"{idx + 1}. {cuisine}")

choice = int(input("\nEnter the number corresponding to your preferred cuisine: ")) - 1

if 0 <= choice < len(top_cuisines):
    selected_cuisine = top_cuisines[choice]
    user_preferences = {
        'Cuisines': selected_cuisine,
        'Price range': 2,
        'Average Cost for two': 500
    }
    recommendations = recommend_restaurants(user_preferences, top_n=5)
    if not recommendations.empty:
        print(f"\nTop Restaurants for Cuisine: {selected_cuisine}\n")
        print(recommendations)
    else:
        print("\nNo recommendations found for this cuisine.\n")
else:
    print("\nInvalid choice. Please restart and select a valid option.\n")
